# Orlando Family Vacation 2026

**August 9–15, 2026** · Mobile itinerary and day-of companion

<div class="day-link-grid">
<a class="day-link-card" href="disney/day-01-typhoon-lagoon/"><strong>🌊 Aug 9 · Typhoon Lagoon</strong><span>Animal Kingdom Lodge · Jiko 6:15</span></a>
<a class="day-link-card" href="disney/day-02-animal-kingdom-hollywood/"><strong>🌿🎬 Aug 10 · Animal Kingdom → Hollywood Studios</strong><span>Confirmed Lightning Lanes · Tiffins 1:00 · Boma 7:00</span></a>
<a class="day-link-card" href="disney/day-03-magic-kingdom/"><strong>🏰 Aug 11 · Magic Kingdom</strong><span>Confirmed Multi Pass · transfer to Hard Rock</span></a>
<a class="day-link-card" href="universal/day-04-epic-universe/"><strong>🌌 Aug 12 · Epic Universe</strong><span>Epic Express · Blue Dragon 5:15</span></a>
<a class="day-link-card" href="universal/day-05-islands-of-adventure/"><strong>🦖 Aug 13 · Islands of Adventure</strong><span>Hagrid’s · Ollivanders · Mythos 2:00</span></a>
<a class="day-link-card" href="universal/day-06-universal-studios/"><strong>🎬 Aug 14 · Universal Studios Florida</strong><span>Shutterbutton’s 10:00 · ice cream and cooler bag</span></a>
<a class="day-link-card" href="universal/day-07-departure/"><strong>✈️ Aug 15 · Favorites and departure</strong><span>Bell Services · parks until ≈2:15 · MCO</span></a>
<a class="day-link-card" href="revisit/"><strong>🔁 Revisit List</strong><span>Favorites with navigation links</span></a>
</div>

## Immediate actions

- [ ] Café L’air de la Sirène breakfast confirmed for Aug 12.
- [ ] Three Broomsticks breakfast confirmed for Aug 13.
- [ ] Leaky Cauldron breakfast confirmed for Aug 14.
- [ ] Confirm Hard Rock after-checkout parking for Aug 15.

## Live park conditions

Each day page includes an experimental live panel:

- Orlando forecast for that trip date when it is within the forecast horizon;
- current waits for selected priority attractions;
- manual refresh plus automatic updates;
- graceful fallback to the official park apps if a third-party request is blocked.

Current waits shown before a park day are reference data, not a prediction.
